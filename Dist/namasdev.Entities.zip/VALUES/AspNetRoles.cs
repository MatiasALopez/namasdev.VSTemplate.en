﻿namespace $safeprojectname$.Values
{
    public class AspNetRoles
    {
        public const string ADMINISTRATOR = "Administrator";
    }
}
