﻿using System;

using namasdev.Data;
using namasdev.Data.Entity;

using $safeprojectname$.Sql;
using MyApp.Entities;

namespace $safeprojectname$
{
    public interface IErrorsRepository : IRepository<Error, Guid>
    {
    }

    public class ErrorsRepository : Repository<SqlContext, Error, Guid>, IErrorsRepository
    {
    }
}
