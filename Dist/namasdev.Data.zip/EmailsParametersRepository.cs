﻿using namasdev.Data;
using namasdev.Data.Entity;

using $safeprojectname$.Sql;
using MyApp.Entities;

namespace $safeprojectname$
{
    public interface IEmailsParametersRepository : IReadOnlyRepository<EmailParameters, short>
    {
    }

    public class EmailsParametersRepository : ReadOnlyRepository<SqlContext, EmailParameters, short>, IEmailsParametersRepository
    {
    }
}
