﻿using MyApp.Entities;

namespace $safeprojectname$.DTO.Emails
{
    public class SendWithParametersParameters : SendParametersBase
    {
        public EmailParameters Parameters { get; set; }
    }
}
