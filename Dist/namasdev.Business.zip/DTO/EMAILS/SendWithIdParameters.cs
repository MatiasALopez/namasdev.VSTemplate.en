﻿namespace $safeprojectname$.DTO.Emails
{
    public class SendWithIdParameters : SendParametersBase
    {
        public short EmailParametersId { get; set; }
    }
}
