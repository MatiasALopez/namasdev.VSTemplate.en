﻿namespace $safeprojectname$.DTO.Users
{
    public class SetDeletedParameters : ParametersEntityBase<string>
    {
    }
}
