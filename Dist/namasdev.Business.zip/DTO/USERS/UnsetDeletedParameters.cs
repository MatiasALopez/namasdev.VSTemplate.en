﻿namespace $safeprojectname$.DTO.Users
{
    public class UnsetDeletedParameters : ParametersEntityBase<string>
    {
    }
}
