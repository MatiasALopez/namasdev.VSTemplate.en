﻿namespace $safeprojectname$.DTO
{
    public class ParametersWithUserBase
    {
        public string LoggedUserId { get; set; }
    }
}
