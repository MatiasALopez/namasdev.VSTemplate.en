﻿using AutoMapper;
using $safeprojectname$.DTO.Emails;

namespace $safeprojectname$.Automapper
{
    public class EmailsProfile : Profile
    {
        public EmailsProfile()
        {
            CreateMap<SendWithIdParameters, SendWithParametersParameters>();
            CreateMap<SendWithSubjectAndBodyParameters,SendWithParametersParameters>();
        }
    }
}
