namespace $safeprojectname$.Metadata.Views
{
    public class UsersViews
    {
        public const string USERS = "Users";
        public const string USER = "User";
    }
}
